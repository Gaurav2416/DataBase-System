STUDENT NAME: Navadia, Parth Mukeshbhai
UTA ID: 1001778479

Task 1:
	
	all the sql commands for the task 1 is given in 'create_table.txt'.

	'task1.lst' is SPOOL file which we get after executing 'create_table.txt' in SQLPLUS. After every output, comments are given for better understanding.