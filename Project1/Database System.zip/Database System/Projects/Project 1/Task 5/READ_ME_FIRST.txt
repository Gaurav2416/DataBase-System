STUDENT NAME: Navadia, Parth Mukeshbhai
UTA ID: 1001778479

Task 5:
	
	all queries are given in 'Commands.txt' file.

	'task5.lst' is SPOOL file which has all the queries and their outputs. Comments are given for better understanding.