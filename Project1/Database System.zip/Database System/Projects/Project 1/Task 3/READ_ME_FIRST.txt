STUDENT NAME: Navadia, Parth Mukeshbhai
UTA ID: 1001778479

Task 3:
	
	all queries are given in 'Commands.txt' file.

	Task 4 is done prioror to Task 3.

	'task3.lst' is SPOOL file which has all the queries and their outputs. Comments are given for better understanding.