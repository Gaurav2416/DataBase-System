STUDENT NAME: Navadia, Parth Mukeshbhai
UTA ID: 1001778479

Task 7:
	
	all queries are given in 'Commands.txt' file.

	'task7.lst' is SPOOL file which has all the queries and their outputs. Comments are given for better understanding.