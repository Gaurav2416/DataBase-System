STUDENT NAME: Navadia, Parth Mukeshbhai
UTA ID: 1001778479

Task 2:

	all the codes for inseting data is given in the folder.
	
	Below is the sequence of executing commands for inserting data into tables.

	1. sqlldr control = 'load_employee_dummy.ctl' log = 'track.log'
	   
	   this command will insert our dummy data from 'EMPLOYEE_DUMMY.txt' into table 'EMPLOYEE'. This data is needed for inserting all the data from 'EMPLOYEE.txt' to table 'EMPLOYEE' as it needs this data as parent key for foreign key 'Super_ssn' of some ids.



	2. sqlldr control = 'load_department_dummy.ctl' log = 'track.log'
	   
	   this command will insert our dummy data from 'DEPATMENT_DUMMY.txt' into table 'DEPARTMENT'. This data is needed for inserting all the data from 'EMPLOYEE.txt' to table 'EMPLOYEE' as it needs this data as parent key for foreign key 'Dno' of most of the ids.



	3. sqlldr control = 'load_employee.ctl' log = 'track.log'
	   
	   this command will insert actual data from 'EMPLOYEE.txt' into table 'EMPLOYEE'.



	4. sqlldr control = 'load_department.ctl' log = 'track.log'
	   
	   this command will insert actual data from 'DEPARTMENT.txt' into table 'DEPARTMENT_DUMMY'. Table 'DEPARTMENT_DUMMY' is temporary table which will be used in next step.



	5. SQL > start update_department.txt
	   
	   this command will be executed into sqlplus. This will merge the data from table 'DEPERTMENT_DUMMY'  to table 'DEPARTMENT' according to primary key of both 'Dnumber'.



	6. sqlldr control = 'load_dept_locations.ctl' log = 'track.log'
	   
	   this command will insert actual data from 'DEPT_LOCATIONS.txt' into table 'DEPT_LOCATIONS'.



	7. sqlldr control = 'load_project.ctl' log = 'track.log'
	   
	   this command will insert actual data from 'PROJECT.txt' into table 'PROJECT'.



	8. sqlldr control = 'load_works_on.ctl' log = 'track.log'
	   
	   this command will insert actual data from 'WORKS_ON.txt' into table 'WORKS_ON'.



	9. sqlldr control = 'load_dependent.ctl' log = 'track.log'
	   
	   this command will insert actual data from 'DEPENDENT.txt' into table 'DEPENDENT'.