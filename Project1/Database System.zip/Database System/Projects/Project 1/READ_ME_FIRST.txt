STUDENT NAME: Navadia, Parth Mukeshbhai
UTA ID: 1001778479

	For each Problem there is one folder coresponding to it. For instance, For Problem 1 -> Folder 'Task 1'

	Please read the 'READ_ME_FIRST.txt' file first located in each folder.