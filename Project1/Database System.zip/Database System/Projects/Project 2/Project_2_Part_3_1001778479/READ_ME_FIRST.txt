STUDENT NAME: Navadia, Parth Mukeshbhai
UTA ID: 1001778479

	For each Part there is one folder coresponding to it. For instance, For Part 1 -> Folder 'Part 1'

	Please read the 'READ_ME_FIRST.txt' file first located in each folder.