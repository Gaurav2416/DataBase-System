STUDENT NAME: Navadia, Parth Mukeshbhai
UTA ID: 1001778479

Part 3:

	Please read the "Documentation.pdf" file for all the specifications.

	to run the the program, Open command prompt here and give following command.
	"python application.py"

	After that, Please open your browser of choice and go to "http://localhost:3000/"