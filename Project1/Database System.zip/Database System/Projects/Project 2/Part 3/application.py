import os
import shutil
import csv
import sys
import sqlite3
import math
import random
from time import time
from flask import Flask,render_template, url_for, flash, redirect, request
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired, FileAllowed
from flask_uploads import UploadSet, configure_uploads, IMAGES, patch_request_class
from flask_bootstrap import Bootstrap
from wtforms import StringField, IntegerField, SubmitField, SelectField
from wtforms.validators import DataRequired


application = Flask(__name__)
bootstrap = Bootstrap(application)

# Configurations
application.config['SECRET_KEY'] = 'blah blah blah blah'

class NameForm(FlaskForm):
	name = StringField('Name', default="Bruce Springsteen")
	submit = SubmitField('Submit')

# ROUTES!
@application.route('/')
def index():
	return render_template('index.html')



@application.route('/printData' , methods=['GET','POST'])
def printData():
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = " SELECT tbl_name FROM sqlite_master WHERE type = 'table';"
	cursor.execute(query)
	tableNames = cursor.fetchall()
	tableNames.pop(0)
	data = {}
	columnNames = {}
	for i in range (len (tableNames)):
		query = "PRAGMA table_info('" +str(tableNames[i][0])+ "');"
		cursor.execute(query)
		columnNames[i] = cursor.fetchall()
		query = "select * from '" +str(tableNames[i][0])+ "'"
		cursor.execute(query)
		data[i] = cursor.fetchall()
	return render_template('printData.html',name1= "USER_ACCOUNTs", tableNames = tableNames, columnNames = columnNames, data = data)



@application.route('/user_accountsInsert')
def user_accountsInsert():
	return render_template('user_accountsInsert.html')

@application.route('/user_accountsData' , methods=['GET','POST'])
def user_accountsData():
	name = (request.form['name'])
	phone = (request.form['phone'])
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = "insert into USER_ACCOUNTs (name, phone) values ('" +str(name)+ "','" +str(phone)+ "')"
	if (cursor.execute(query)):
		message = "Data added successfully."
	connection.commit()
	return render_template('user_accountsInsert.html', message = message)



@application.route('/user_rolesInsert')
def user_rolesInsert():
	return render_template('user_rolesInsert.html')

@application.route('/user_rolesData' , methods=['GET','POST'])
def user_rolesData():
	roleName = (request.form['roleName'])
	description = (request.form['description'])
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = "insert into USER_ROLEs (RoleName, Description) values ('" +str(roleName)+ "','" +str(description)+ "')"
	if (cursor.execute(query)):
		message = "Data added successfully."
	connection.commit()
	return render_template('user_rolesInsert.html', message = message)



@application.route('/tablesInsert')
def tablesInsert():
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = " SELECT IdNo FROM USER_ACCOUNTs;"
	cursor.execute(query)
	user_accounts = cursor.fetchall()
	return render_template('tablesInsert.html', user_accounts = user_accounts)

@application.route('/tablesData' , methods=['GET','POST'])
def tablesData():
	tableName = (request.form['tableName'])
	description = (request.form['description'])
	userId = (request.form['userAccount'])
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = "insert into TABLEs (TableName, Description, UserId) values ('" +str(tableName)+ "','" +str(description)+ "'," +str(userId)+ ")"
	if (cursor.execute(query)):
		message = "Data added successfully."
	connection.commit()
	query = " SELECT IdNo FROM USER_ACCOUNTs;"
	cursor.execute(query)
	user_accounts = cursor.fetchall()
	return render_template('tablesInsert.html', user_accounts = user_accounts, message = message)



@application.route('/account_privilegesInsert')
def account_privilegesInsert():
	return render_template('account_privilegesInsert.html')

@application.route('/account_privilegesData' , methods=['GET','POST'])
def account_privilegesData():
	privilegeName = (request.form['privilegeName'])
	description = (request.form['description'])
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = "insert into ACCOUNT_PRIVILEGEs (PrivilegeName, Description) values ('" +str(privilegeName)+ "','" +str(description)+ "')"
	if (cursor.execute(query)):
		message = "Data added successfully."
	connection.commit()
	return render_template('account_privilegesInsert.html', message = message)



@application.route('/relation_privilegesInsert')
def relation_privilegesInsert():
	return render_template('relation_privilegesInsert.html')

@application.route('/relation_privilegesData' , methods=['GET','POST'])
def relation_privilegesData():
	privilegeName = (request.form['privilegeName'])
	description = (request.form['description'])
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = "insert into RELATION_PRIVILEGEs (PrivilegeName, Description) values ('" +str(privilegeName)+ "','" +str(description)+ "')"
	if (cursor.execute(query)):
		message = "Data added successfully."
	connection.commit()
	return render_template('relation_privilegesInsert.html', message = message)



@application.route('/user_accountAndUser_roleRelate')
def user_accountAndUser_roleRelate():
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = " SELECT IdNo FROM USER_ACCOUNTs;"
	cursor.execute(query)
	user_accounts = cursor.fetchall()
	query = " SELECT RoleId FROM USER_ROLEs;"
	cursor.execute(query)
	user_roles = cursor.fetchall()
	return render_template('user_accountAndUser_roleRelate.html', user_accounts = user_accounts, user_roles = user_roles)

@application.route('/user_accountAndUser_roleData' , methods=['GET','POST'])
def user_accountAndUser_roleData():
	userId = (request.form['userAccount'])
	userRole = (request.form['userRole'])
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = "UPDATE USER_ACCOUNTs SET UserRole = " +(userRole)+ " where IdNo == " +(userId)+ ""
	if (cursor.execute(query)):
		message = "Data added successfully."
	connection.commit()
	query = " SELECT IdNo FROM USER_ACCOUNTs;"
	cursor.execute(query)
	user_accounts = cursor.fetchall()
	query = " SELECT RoleId FROM USER_ROLEs;"
	cursor.execute(query)
	user_roles = cursor.fetchall()
	return render_template('user_accountAndUser_roleRelate.html',user_accounts = user_accounts, user_roles = user_roles, message = message)



@application.route('/account_privilegeAndUser_roleRelate')
def account_privilegeAndUser_roleRelate():
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = " SELECT PrivilegeId FROM ACCOUNT_PRIVILEGEs;"
	cursor.execute(query)
	account_privileges = cursor.fetchall()
	query = " SELECT RoleId FROM USER_ROLEs;"
	cursor.execute(query)
	user_roles = cursor.fetchall()
	return render_template('account_privilegeAndUser_roleRelate.html', account_privileges = account_privileges, user_roles = user_roles)

@application.route('/account_privilegeAndUser_roleData' , methods=['GET','POST'])
def account_privilegeAndUser_roleData():
	accountPrivilege = (request.form['accountPrivilege'])
	userRole = (request.form['userRole'])
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = "insert into GIVEN_PRIVILEGEs (Privilege, UserRole) values (" +(accountPrivilege)+ "," +(userRole)+ ")"
	if (cursor.execute(query)):
		message = "Data added successfully."
	connection.commit()
	query = " SELECT PrivilegeId FROM ACCOUNT_PRIVILEGEs;"
	cursor.execute(query)
	account_privileges = cursor.fetchall()
	query = " SELECT RoleId FROM USER_ROLEs;"
	cursor.execute(query)
	user_roles = cursor.fetchall()
	return render_template('account_privilegeAndUser_roleRelate.html', account_privileges = account_privileges, user_roles = user_roles, message = message)



@application.route('/relation_privilegeAndUser_roleAndTableRelate')
def relation_privilegeAndUser_roleAndTableRelate():
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = " SELECT PrivilegeId FROM RELATION_PRIVILEGEs;"
	cursor.execute(query)
	relation_privileges = cursor.fetchall()
	query = " SELECT RoleId FROM USER_ROLEs;"
	cursor.execute(query)
	user_roles = cursor.fetchall()
	query = " SELECT TableId FROM TABLEs;"
	cursor.execute(query)
	tables = cursor.fetchall()
	return render_template('relation_privilegeAndUser_roleAndTableRelate.html', relation_privileges = relation_privileges, user_roles = user_roles, tables = tables)

@application.route('/relation_privilegeAndUser_roleAndTableData' , methods=['GET','POST'])
def relation_privilegeAndUser_roleAndTableData():
	relationPrivilege = (request.form['relationPrivilege'])
	userRole = (request.form['userRole'])
	table = (request.form['table'])
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = "insert into TRACKs values ("+(table)+"," +(userRole)+ ", " +(relationPrivilege)+ ")"
	if (cursor.execute(query)):
		message = "Data added successfully."
	connection.commit()
	query = " SELECT PrivilegeId FROM RELATION_PRIVILEGEs;"
	cursor.execute(query)
	relation_privileges = cursor.fetchall()
	query = " SELECT RoleId FROM USER_ROLEs;"
	cursor.execute(query)
	user_roles = cursor.fetchall()
	query = " SELECT TableId FROM TABLEs;"
	cursor.execute(query)
	tables = cursor.fetchall()
	return render_template('relation_privilegeAndUser_roleAndTableRelate.html', relation_privileges = relation_privileges, user_roles = user_roles, tables = tables, message = message)



@application.route('/user_roleAndPrivilegeRetrive')
def user_roleAndPrivilegeRetrive():
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = " SELECT RoleId FROM USER_ROLEs;"
	cursor.execute(query)
	user_roles = cursor.fetchall()
	return render_template('user_roleAndPrivilegeRetrive.html', user_roles = user_roles)

@application.route('/user_roleAndPrivilegeData' , methods=['GET','POST'])
def user_roleAndPrivilegeData():
	userRole = (request.form['userRole'])
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = "select ACCOUNT_PRIVILEGEs.PrivilegeId, ACCOUNT_PRIVILEGEs.PrivilegeName, ACCOUNT_PRIVILEGEs.Description from ACCOUNT_PRIVILEGEs JOIN GIVEN_PRIVILEGEs ON ACCOUNT_PRIVILEGEs.PrivilegeId = GIVEN_PRIVILEGEs.Privilege where GIVEN_PRIVILEGEs.UserRole = " +(userRole)+ " group by ACCOUNT_PRIVILEGEs.PrivilegeId"
	cursor.execute(query)
	accountPrivilegeData = cursor.fetchall()
	query = "select RELATION_PRIVILEGEs.PrivilegeId, RELATION_PRIVILEGEs.PrivilegeName, RELATION_PRIVILEGEs.Description from RELATION_PRIVILEGEs JOIN TRACKs ON RELATION_PRIVILEGEs.PrivilegeId = TRACKs.Privilege where TRACKs.UserRole = " +(userRole)+ " group by RELATION_PRIVILEGEs.PrivilegeId"
	cursor.execute(query)
	relationPrivilegeData = cursor.fetchall()
	query = "PRAGMA table_info(ACCOUNT_PRIVILEGEs);"
	cursor.execute(query)
	columnNames = cursor.fetchall()
	query = " SELECT RoleId FROM USER_ROLEs;"
	cursor.execute(query)
	user_roles = cursor.fetchall()
	return render_template('user_roleAndPrivilegeRetrive.html', user_roles = user_roles, accountPrivilegeData = accountPrivilegeData, relationPrivilegeData = relationPrivilegeData, columnNames = columnNames)



@application.route('/user_accountAndPrivilegeRetrive')
def user_accountAndPrivilegeRetrive():
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = " SELECT IdNo FROM USER_ACCOUNTs;"
	cursor.execute(query)
	user_accounts = cursor.fetchall()
	return render_template('user_accountAndPrivilegeRetrive.html', user_accounts = user_accounts)

@application.route('/user_accountAndPrivilegeData' , methods=['GET','POST'])
def user_accountAndPrivilegeData():
	userAccount = (request.form['userAccount'])
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = "select ACCOUNT_PRIVILEGEs.PrivilegeId, ACCOUNT_PRIVILEGEs.PrivilegeName, ACCOUNT_PRIVILEGEs.Description from ACCOUNT_PRIVILEGEs JOIN GIVEN_PRIVILEGEs JOIN USER_ACCOUNTs ON ACCOUNT_PRIVILEGEs.PrivilegeId = GIVEN_PRIVILEGEs.Privilege and GIVEN_PRIVILEGEs.UserRole = USER_ACCOUNTs.UserRole where USER_ACCOUNTs.IdNo = " +(userAccount)+ " group by ACCOUNT_PRIVILEGEs.PrivilegeId"
	cursor.execute(query)
	accountPrivilegeData = cursor.fetchall()
	query = "select RELATION_PRIVILEGEs.PrivilegeId, RELATION_PRIVILEGEs.PrivilegeName, RELATION_PRIVILEGEs.Description from RELATION_PRIVILEGEs JOIN TRACKs JOIN USER_ACCOUNTs ON RELATION_PRIVILEGEs.PrivilegeId = TRACKs.Privilege and TRACKs.UserRole = USER_ACCOUNTs.UserRole where USER_ACCOUNTs.IdNo = " +(userAccount)+ " group by RELATION_PRIVILEGEs.PrivilegeId"
	cursor.execute(query)
	relationPrivilegeData = cursor.fetchall()
	query = "PRAGMA table_info(ACCOUNT_PRIVILEGEs);"
	cursor.execute(query)
	columnNames = cursor.fetchall()
	query = " SELECT IdNo FROM USER_ACCOUNTs;"
	cursor.execute(query)
	user_accounts = cursor.fetchall()
	return render_template('user_accountAndPrivilegeRetrive.html', user_accounts = user_accounts, accountPrivilegeData = accountPrivilegeData, relationPrivilegeData = relationPrivilegeData, columnNames = columnNames)



@application.route('/privilegeToUser_accountRetrive')
def privilegeToUser_accountRetrive():
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = " SELECT IdNo FROM USER_ACCOUNTs;"
	cursor.execute(query)
	user_accounts = cursor.fetchall()
	privileges = []
	query = " SELECT PrivilegeId FROM ACCOUNT_PRIVILEGEs;"
	cursor.execute(query)
	privileges = cursor.fetchall()
	query = " SELECT PrivilegeId FROM RELATION_PRIVILEGEs;"
	cursor.execute(query)
	temp = cursor.fetchall()
	for i in temp:
		privileges.append(i)
	return render_template('privilegeToUser_accountRetrive.html', user_accounts = user_accounts, privileges = privileges)

@application.route('/privilegeToUser_accountData' , methods=['GET','POST'])
def privilegeToUser_accountData():
	privilege = (request.form['privilege'])
	userAccount = (request.form['userAccount'])
	connection = sqlite3.connect('database.db')
	cursor = connection.cursor()
	query = "select exists (select ACCOUNT_PRIVILEGEs.PrivilegeId, ACCOUNT_PRIVILEGEs.PrivilegeName, ACCOUNT_PRIVILEGEs.Description from ACCOUNT_PRIVILEGEs JOIN GIVEN_PRIVILEGEs JOIN USER_ACCOUNTs ON ACCOUNT_PRIVILEGEs.PrivilegeId = GIVEN_PRIVILEGEs.Privilege and GIVEN_PRIVILEGEs.UserRole = USER_ACCOUNTs.UserRole where USER_ACCOUNTs.IdNo = " +(userAccount)+ " and GIVEN_PRIVILEGEs.Privilege = " +(privilege)+ " group by ACCOUNT_PRIVILEGEs.PrivilegeId)"
	cursor.execute(query)
	exists = cursor.fetchall()
	if (exists[0][0] == 1):
		message = "Yes, Privilege Id " +(privilege)+ " is granted to User Account " +(userAccount)+ "."
	else:
		query = "select exists (select RELATION_PRIVILEGEs.PrivilegeId, RELATION_PRIVILEGEs.PrivilegeName, RELATION_PRIVILEGEs.Description from RELATION_PRIVILEGEs JOIN TRACKs JOIN USER_ACCOUNTs ON RELATION_PRIVILEGEs.PrivilegeId = TRACKs.Privilege and TRACKs.UserRole = USER_ACCOUNTs.UserRole where USER_ACCOUNTs.IdNo = " +(userAccount)+ " and TRACKs.Privilege = " +(privilege)+ " group by RELATION_PRIVILEGEs.PrivilegeId)"
		cursor.execute(query)
		exists = cursor.fetchall()
		if (exists[0][0] == 1):
			message = "Yes, Privilege Id " +(privilege)+ " is GRANTED to User Account " +(userAccount)+ "."
		else:
			message = "No, Privilege Id " +(privilege)+ " is NOT GRANTED to User Account " +(userAccount)+ "."
	query = " SELECT IdNo FROM USER_ACCOUNTs;"
	cursor.execute(query)
	user_accounts = cursor.fetchall()
	privileges = []
	query = " SELECT PrivilegeId FROM ACCOUNT_PRIVILEGEs;"
	cursor.execute(query)
	privileges = cursor.fetchall()
	query = " SELECT PrivilegeId FROM RELATION_PRIVILEGEs;"
	cursor.execute(query)
	temp = cursor.fetchall()
	for i in temp:
		privileges.append(i)
	return render_template('privilegeToUser_accountRetrive.html', user_accounts = user_accounts, privileges = privileges, message = message)


@application.errorhandler(404)
@application.route("/error404")
def page_not_found(error):
	return render_template('404.html',title='404')

@application.errorhandler(500)
@application.route("/error500")
def requests_error(error):
	return render_template('500.html',title='500')
port = int(os.getenv('PORT', '3000'))
application.debug = True
application.run(host='0.0.0.0', port=port, debug = True)