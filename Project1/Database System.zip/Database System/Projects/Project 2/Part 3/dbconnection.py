import pyodbc
import os

server = 'navadia9699.database.windows.net'
database = 'databse'
username = 'parth'
password = 'ArrOn9699'
driver = '{ODBC Driver 17 for SQL Server}'
dbconnect = pyodbc.connect('DRIVER='+driver+';PORT=1433;SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)