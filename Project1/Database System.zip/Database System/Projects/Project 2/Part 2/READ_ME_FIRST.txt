STUDENT NAME: Navadia, Parth Mukeshbhai
UTA ID: 1001778479

Part 2:
	
	All the sql commands for the Part 2 is given in 'create_table.txt'.

	Please read the "Documentation.pdf" file for all the specifications.

	"part2.lst" file is a SPOOL file which contains output of the SQL commands with comments for beter understanding.