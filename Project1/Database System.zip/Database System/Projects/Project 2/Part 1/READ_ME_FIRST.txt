STUDENT NAME: Navadia, Parth Mukeshbhai
UTA ID: 1001778479

Part 1:

	All the documents required for Part 1 is given here. Please read "Documentation.pdf" file for the simplifications.