import cx_Oracle as con
import numpy as np
import Config as c
import pandas as pd

source='C:/Users/16824/OneDrive/Desktop/Project/DBS/';
fileName= 'US_confirmed_cases.csv'; 
df = pd.read_csv (source+fileName)
# df=df.replace(np.nan,'',regex=True)
df= df[df['County'].notnull()]
records= df.melt(id_vars=['Province_State', 'County'],var_name='Date',value_name='Value')
# print(records['Date'].dtypes)
records= records.values.tolist();
# print(records[:3])
try:
    connection= con.connect(c.username+'/'+c.password+c.connectionString) 
except con.Error as error :
    print(error);
else:
    print(connection.version) 
    try:
        print('Inserting data.......')
        sqlQuery= """INSERT INTO CONFIRMED_CASE VALUES (:1, :2, TO_DATE(:3,'mm-dd-yyyy'), :4)"""
        cur= connection.cursor()
        cur.executemany(sqlQuery,records)
        connection.commit();
    except Exception as error:
        print('Error while Inserting',error);
    else:
        print('Insert finished');
finally:
    if connection:
        cur.close()
        connection.close()  
