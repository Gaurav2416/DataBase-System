username= "gst5801"
password= "Gauravtaneja123"
connectionString= "@//acaddbprod.uta.edu:1523/pcse1p.data.uta.edu"

# username="c##scott"
# password="tiger"
# connectionString= "@//localhost:1521/orcl"
