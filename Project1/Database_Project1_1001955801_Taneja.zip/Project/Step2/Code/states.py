import cx_Oracle as con
import numpy as np
import Config as c
import pandas as pd

source='C:/Users/16824/OneDrive/Desktop/Project/DBS/';
fileName= 'US_state.csv'; 
df = pd.read_csv (source+fileName)
df= df.replace(np.nan,0,regex=True)
records= df.values.tolist();
print(records[:2])
connection = None

try:
    # Establishing Connection
    connection= con.connect(c.username+'/'+c.password+c.connectionString) 
except con.Error as error :
    print(error);
else:
    print(connection.version) 
    try:
        print('Inserting.....')
        # Inserting data into table
        sqlQuery= """INSERT INTO STATE VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10)"""
        #Intiating cursor to execute Query
        cur= connection.cursor()
        cur.executemany(sqlQuery,records)
        connection.commit();
    except Exception as error:
        print('Error while Inserting',error);
    else:
        print('Insert finished');
finally:
    if connection:
        cur.close()
        #Connection is Closed
        connection.close() 