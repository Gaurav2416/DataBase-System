Q) Write one or more database programs to load the records that will be provided to you into each of the tables that you created.
The supplied data is synthetic and may not represent the ground reality. You might have to pivot some data to suit to the schema given.
You can use any programming or scripting language you are familiar with (JAVA with JDBC, Pro*C, PERL, PHP, Python, etc.).

Steps for data import
1.There are separate code for all files.
2.Please set the config file first.
3.Please set the path of the file and name of file 
Do all the steps before executing code in python.