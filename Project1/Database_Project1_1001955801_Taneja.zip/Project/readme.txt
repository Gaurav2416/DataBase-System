 There are two files in each folder one is the question and the query and second is the output.

Following are the data inconsistancy in database.These data are removed from the table.

1. Data discrepency in county table some states are not present not present in state table.(Diamond Princess,Grand Princess-> ship)
These tables are deleted from the county table.

2. These names are deleted from the vacciantions table.
Bureau of Prisons', 'Dept of Defense', 'Federated States of Micronesia', 'Indian Health Svc', 'Marshall Islands', 'Republic of Palau', 'Veterans Health

Bureau of Prisons	36450	34255	N/A	N/A	24049	0	10130	0

Dept of Defense	872325	508965	N/A	N/A	424284	0	75347	0

Federated States of Micronesia	19400	6254	18718	6034	6210	5992	17	16

Indian Health Svc	461000	224095	N/A	N/A	174664	0	45751	0

Marshall Islands	21000	4258	35951	7289	3844	6581	376	644

Republic of Palau	6000	3228	33506	18026	3109	17362	119	665

Veterans Health	1543525	1013974	N/A	N/A	813455	0	199554	0

3.The Changes are made to excel file.

4.For the file confirmed cases and deaths has 12 lakh rows while inserting into omega database it gives outspace 
error so stored the data on local machine.
